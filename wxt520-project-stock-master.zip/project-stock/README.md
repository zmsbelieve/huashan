# Angular 4.0从入门到实战 打造股票管理网站

#### 项目介绍
项目来源于慕课网  [Angular 4.0从入门到实战 打造股票管理网站](http://coding.imooc.com/class/94.html)  您可以打开 [链接](http://coding.imooc.com/class/94.html) 了解详细技术点。  
项目的创建使用了 [Angular CLI](https://github.com/angular/angular-cli) version 1.7.3。  

#### 软件架构
软件架构说明


#### 安装教程

1. xxxx
2. xxxx
3. xxxx


#### 使用说明

1. xxxx
2. xxxx
3. xxxx


#### 请联系我

QQ邮箱： 2476992987@qq.com