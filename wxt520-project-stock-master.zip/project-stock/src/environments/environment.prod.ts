export const environment = {
  production: true,
  weixinhao: '这是生产环境'
};
