export const environment = {
  production: true,
  weixinhao: '这是测试环境'
};
