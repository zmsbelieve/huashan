package com.atguigu.mongoserviceImpl;

import com.atguigu.mongoentity.User;
import com.atguigu.mongoservice.UserService;
import org.springframework.stereotype.Service;

@Service("userService")
public class UserServiceImpl implements UserService {
//    @Autowired
//    UserRepository userRepository;
    @Override
    public void save(User user) {
//        userRepository.save(user);
    }

    @Override
    public User findByName(String name) {
        return null;
    }
}
