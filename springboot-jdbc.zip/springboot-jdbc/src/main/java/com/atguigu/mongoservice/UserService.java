package com.atguigu.mongoservice;

import com.atguigu.mongoentity.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserService {
    public void save(User user);

    public User findByName(String name);
}
