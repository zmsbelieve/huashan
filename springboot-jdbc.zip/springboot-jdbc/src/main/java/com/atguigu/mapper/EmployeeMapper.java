package com.atguigu.mapper;

import com.atguigu.entity.Employee;

import java.util.List;
public interface EmployeeMapper {

    List<Employee> findAll();

    Employee findById(int id);
}
