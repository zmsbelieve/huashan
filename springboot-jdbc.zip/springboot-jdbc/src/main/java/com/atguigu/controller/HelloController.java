package com.atguigu.controller;

import com.atguigu.entity.Employee;
import com.atguigu.mapper.EmployeeMapper;
import com.atguigu.mongoentity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Controller
public class HelloController {
    @Autowired
    DataSource dataSource;
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    MongoTemplate mongoTemplate;
    @Autowired
    EmployeeMapper employeeMapper;
    @GetMapping("/hello")
    @ResponseBody
    public List<Map<String, Object>> testJdbc() throws SQLException {
        System.out.println(dataSource.getClass());
        Connection connection = dataSource.getConnection();
        System.out.println(connection);
        List<Map<String, Object>> maps = jdbcTemplate.queryForList("select * from test");
        System.out.println(maps);
        return maps;
    }
    @GetMapping("/testMongoDb")
    @ResponseBody
    public User testMongoDb(){
        User byId = mongoTemplate.findById("5aad14310046272301a822f4", User.class);
        return byId;
    }
    @GetMapping("/testMybatis")
    @ResponseBody
    public List<Employee> testMybatis(){
        List<Employee> employees = employeeMapper.findAll();
        return employees;
    }
}
