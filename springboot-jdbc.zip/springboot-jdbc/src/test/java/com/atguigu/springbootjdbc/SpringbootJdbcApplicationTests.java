package com.atguigu.springbootjdbc;

import com.atguigu.entity.Person;
import com.atguigu.mongoentity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.jdbc.core.*;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringbootJdbcApplicationTests {
    @Autowired
    DataSource dataSource;
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    MongoTemplate mongoTemplate;
    @Test
    public void contextLoads() {
        System.out.println(dataSource.getClass());
    }
    @Test
    public void testJdbcTemplate1(){
        List<Person> ls = jdbcTemplate.execute(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(Connection conn)
                    throws SQLException {
                return conn.prepareStatement("select * from person");
            }}, new PreparedStatementCallback<List<Person>>() {
            @Override
            public List<Person> doInPreparedStatement(PreparedStatement pstmt)
                    throws SQLException, DataAccessException {
                pstmt.execute();
                ResultSet rs = pstmt.getResultSet();
                List<Person> ls =new ArrayList<>();
                while(rs.next()){
                    Person p = new Person();
                    p.setId(rs.getInt(1));
                    p.setAddress(rs.getString(2));
                    p.setAge(rs.getInt(3));
                    p.setName(rs.getString(4));
                    ls.add(p);
                }
                return ls;
            }});
        System.out.println(ls);
    }
    @Test
    public void testJdbcTemplate2(){
        //插入与删除
        String insertSql = "insert into person values(?,?,?,?)";
        jdbcTemplate.update(insertSql, new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setInt(1,4);
                ps.setString(2,"China");
                ps.setInt(3,19);
                ps.setString(4,"AABBCC");
            }
        });
        jdbcTemplate.update("delete from person where id = ?",4);
    }
    @Test
    public void testJdbcTemplate3(){
        List<Person> ls = jdbcTemplate.query("select * from person", new RowMapper<Person>() {
            //有几条记录就执行几次类似游标
            //返回的对象会自动存储在一个ResultSet集合里面
            //results.add(this.rowMapper.mapRow(rs, rowNum++));这个方法多次调用mapRow
            //然后将值add进集合里面 最后再将这个集合返回给我们
            @Override
            public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
                Person p =new Person();
                p.setId(rs.getInt(1));
                p.setAddress(rs.getString(2));
                p.setAge(rs.getInt(3));
                p.setName(rs.getString(4));
                return p;
            }
        });
        System.out.println(ls);
    }
    @Test
    public void testMongoDb(){
        List<User> all = mongoTemplate.findAll(User.class);
        User user =new User();
        user.setId("3");
        user.setName("测试");
        user.setAge(19);
//        mongoTemplate.save(user,"student");
        List<User> users = mongoTemplate.find(new Query(Criteria.where("name").is("测试")), User.class);
        mongoTemplate.updateMulti(new Query(Criteria.where("name").is("测试")),new Update().addToSet("adress","beijing"),User.class);
        System.out.println(users);
    }
}
